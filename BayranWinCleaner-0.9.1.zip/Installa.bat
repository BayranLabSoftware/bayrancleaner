@echo off
rem Doppio clic qui. Il .bat serve solo a lanciare il vero installatore
rem aggirando il blocco di PowerShell sugli script, che altrimenti si
rem rifiuterebbe di partire senza dire perche'.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installa.ps1"
pause
