# Installa Bayran WinCleaner per l'utente corrente.
#
# Non serve l'amministratore: il programma va nella cartella dei programmi
# dell'utente, non in quella di sistema. Un pulitore che chiede i privilegi
# di amministratore solo per installarsi comincia male.

$ErrorActionPreference = "Stop"
$qui = Split-Path -Parent $MyInvocation.MyCommand.Path
$nome = "Bayran WinCleaner"
$dove = Join-Path $env:LOCALAPPDATA "Programs\Bayran WinCleaner"

function Titolo($t) { Write-Host ""; Write-Host $t -ForegroundColor Cyan }

Titolo "Bayran WinCleaner - installazione"

# ---- 1. che processore ha questo computer ----
$arch = $env:PROCESSOR_ARCHITECTURE
if ($arch -eq "ARM64") { $cartella = "arm64" } else { $cartella = "x64" }
$sorgente = Join-Path $qui "programma\$cartella"
if (-not (Test-Path $sorgente)) {
  Write-Host "Non trovo la versione per $arch in $sorgente" -ForegroundColor Red
  exit 1
}
Write-Host "  processore: $arch  ->  uso la versione $cartella"

# ---- 2. serve il runtime .NET ----
# Il programma pesa 27 MB invece di 130 perche' usa il runtime di sistema
# invece di portarselo dietro. Se non c'e' lo si installa.
$runtime = $false
try {
  $elenco = & dotnet --list-runtimes 2>$null
  if ($elenco -match "Microsoft\.WindowsDesktop\.App 10\.") { $runtime = $true }
} catch { }

if (-not $runtime) {
  Write-Host "  manca il runtime .NET 10: lo installo (serve una volta sola)"
  try {
    & winget install --id Microsoft.DotNet.DesktopRuntime.10 `
        --accept-source-agreements --accept-package-agreements -h
  } catch {
    Write-Host ""
    Write-Host "Non sono riuscito a installarlo da solo." -ForegroundColor Yellow
    Write-Host "Aprilo tu da qui e poi rilancia questo installatore:"
    Write-Host "  https://dotnet.microsoft.com/download/dotnet/10.0"
    Write-Host "  (serve 'Desktop Runtime' per $arch)"
    exit 1
  }
} else {
  Write-Host "  runtime .NET 10: c'e' gia'"
}

# ---- 3. copia ----
if (Test-Path $dove) {
  Write-Host "  c'era gia' una versione: la sostituisco"
  Get-Process BayranWinCleaner -EA SilentlyContinue | Stop-Process -Force -EA SilentlyContinue
  Start-Sleep -Milliseconds 800
  # i dati dell'utente NON stanno qui dentro: stanno in AppData e restano
  Remove-Item $dove -Recurse -Force -EA SilentlyContinue
}
New-Item -ItemType Directory -Force -Path $dove | Out-Null
Copy-Item "$sorgente\*" $dove -Recurse -Force
$exe = Join-Path $dove "BayranWinCleaner.exe"
Write-Host "  copiato in: $dove"

# La versione si legge DAL programma appena copiato, non si scrive qui a mano.
# Scritta a mano era rimasta 0.9.0 mentre il programma andava avanti: e'
# proprio la chiave che Windows mostra in "Installazione applicazioni" ed e'
# quella che Bayran legge per vedere se stesso nella sezione Applicazioni.
$versione = (Get-Item $exe).VersionInfo.FileVersion
if (-not $versione) { $versione = "0.0.0" }
$versione = ($versione -split ' ')[0]
Write-Host "  versione: $versione"

# ---- 4. i collegamenti ----
$ws = New-Object -ComObject WScript.Shell
foreach ($d in @(
    (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"),
    [Environment]::GetFolderPath("Desktop"))) {
  $lnk = $ws.CreateShortcut((Join-Path $d "$nome.lnk"))
  $lnk.TargetPath = $exe
  $lnk.WorkingDirectory = $dove
  $lnk.IconLocation = $exe
  $lnk.Description = "Pulizia del disco, con tutto reversibile dal Cestino"
  $lnk.Save()
}
Write-Host "  collegamenti creati: menu Start e Scrivania"

# ---- 5. il disinstallatore ----
# Si registra dove Windows tiene l'elenco dei programmi installati, cosi'
# compare in "Installazione applicazioni" e si toglie da li' come tutti gli
# altri. E' anche la stessa chiave che legge la sezione Applicazioni di
# Bayran: se non ci fosse, il programma non vedrebbe se stesso.
$disinstalla = Join-Path $dove "Disinstalla.ps1"
@"
`$ErrorActionPreference = 'SilentlyContinue'
Get-Process BayranWinCleaner | Stop-Process -Force
Start-Sleep -Milliseconds 800
Remove-Item '$dove' -Recurse -Force
Remove-Item (Join-Path `$env:APPDATA 'Microsoft\Windows\Start Menu\Programs\$nome.lnk') -Force
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) '$nome.lnk') -Force
Remove-Item 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BayranWinCleaner' -Recurse -Force
Write-Host 'Bayran WinCleaner rimosso. I tuoi dati in AppData\BayranWinCleaner restano:'
Write-Host (Join-Path `$env:LOCALAPPDATA 'BayranWinCleaner')
"@ | Set-Content -Encoding UTF8 $disinstalla

$k = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BayranWinCleaner"
New-Item -Path $k -Force | Out-Null
Set-ItemProperty $k DisplayName    $nome
Set-ItemProperty $k DisplayVersion $versione
Set-ItemProperty $k Publisher      "BayranLab Software"
Set-ItemProperty $k DisplayIcon    $exe
Set-ItemProperty $k InstallLocation $dove
Set-ItemProperty $k NoModify 1 -Type DWord
Set-ItemProperty $k NoRepair 1 -Type DWord
Set-ItemProperty $k UninstallString `
  "powershell -NoProfile -ExecutionPolicy Bypass -File `"$disinstalla`""
Write-Host "  registrato in Installazione applicazioni"

Titolo "Fatto."
Write-Host "Lo trovi nel menu Start e sulla Scrivania come `"$nome`"."
Write-Host ""
Write-Host "La prima volta Windows dira' che non conosce il programma:" -ForegroundColor Yellow
Write-Host "e' vero, non e' firmato. Premi 'Ulteriori informazioni' e poi"
Write-Host "'Esegui comunque'. Succede perche' firmare costa e BayranLab"
Write-Host "non e' ancora registrata come azienda."
Write-Host ""
Write-Host "Per toglierlo: Installazione applicazioni di Windows, come tutti gli altri."
