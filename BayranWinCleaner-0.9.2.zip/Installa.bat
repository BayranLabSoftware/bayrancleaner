@echo off
rem Doppio clic qui. Il .bat serve a due cose:
rem  - aggirare il blocco di PowerShell sugli script, che altrimenti si
rem    rifiuterebbe di partire senza dire perche';
rem  - togliersi subito di mezzo. "start" lancia l'installatore staccato e
rem    "exit" chiude questa finestra: se restasse aperta, dietro al wizard
rem    ci sarebbe una console nera, che e' esattamente cio' che il wizard
rem    serve a non far vedere.
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Installa.ps1"
exit
