﻿# Installazione di Bayran WinCleaner.
#
# Parametri:
#   -silenzioso        installa senza interfaccia. Lo usa l'aggiornamento
#                      automatico, che non ha nessuno davanti allo schermo.
#   -lingua it|en      lingua dell'interfaccia di installazione.
#   -cartella <path>   cartella di destinazione.
#
# Non richiede privilegi di amministratore: l'applicazione viene installata
# nel profilo dell'utente corrente.
#
# TRE VINCOLI, tutti verificati sul campo:
#  1) questo file deve restare UTF-8 CON BOM. Windows PowerShell 5.1 altrimenti
#     lo interpreta come ANSI: i caratteri accentati vengono corrotti e lo
#     script termina con un errore di sintassi.
#  2) la barra del titolo va impostata su scuro esplicitamente, altrimenti la
#     finestra presenta corpo scuro e intestazione chiara.
#  3) l'installazione non deve essere eseguita sul thread dell'interfaccia:
#     l'installazione del runtime .NET puo' richiedere minuti, e Windows
#     contrassegna come "Non risponde" ogni finestra che non ridisegna entro
#     cinque secondi.
param([switch]$silenzioso, [string]$lingua = "", [string]$cartella = "")

$ErrorActionPreference = "Stop"
$qui = Split-Path -Parent $MyInvocation.MyCommand.Path
$nome = "Bayran WinCleaner"

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Finestre {
  [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
  [DllImport("user32.dll")]   public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")]   public static extern bool SetProcessDPIAware();
  [DllImport("dwmapi.dll")]   public static extern int DwmSetWindowAttribute(
      IntPtr h, int attr, ref int val, int size);
}
"@
[void][Finestre]::ShowWindow([Finestre]::GetConsoleWindow(), 0)

# L'aggiornamento automatico estrae sempre il pacchetto in
# %TEMP%\bayran-aggiornamento. Nessun utente installa da quel percorso.
#
# Il controllo serve alle versioni gia' distribuite: il loro aggiornatore
# invoca questo script senza -silenzioso, perche' al momento della loro
# compilazione l'installazione avveniva da console e il parametro non
# esisteva. Senza questa riga, l'aggiornamento resterebbe in attesa di un
# clic su una finestra comparsa mentre l'applicazione si era gia' chiusa.
if ($qui -like (Join-Path $env:TEMP "bayran-aggiornamento*")) { $silenzioso = $true }

# ------------------------------------------------------------------ testi ---

$T = @{
  it = @{
    titolo      = "Installazione di Bayran WinCleaner"
    sottotitolo = "Versione {0} · BayranLab Software"
    lingua      = "Lingua"
    cartella    = "Cartella di installazione"
    sfoglia     = "Sfoglia…"
    nota        = "L'installazione non richiede privilegi di amministratore."
    annulla     = "Annulla"
    installa    = "Installa"
    inCorso     = "Installazione in corso"
    chiudi      = "Chiudi"
    avvia       = "Avvia"
    completata  = "Installazione completata"
    esito       = "Bayran WinCleaner è disponibile nel menu Start e sulla Scrivania."
    esito2      = "Per rimuoverlo, utilizzare «Installazione applicazioni» di Windows. I dati dell'utente vengono conservati."
    fallita     = "Installazione non riuscita"
    scegliCart  = "Selezionare la cartella di destinazione"
    pRuntime    = "Verifica dei componenti richiesti"
    pRuntimeNo  = "Installazione del runtime .NET 10 in corso"
    pCopia      = "Copia dei file"
    pColleg     = "Creazione dei collegamenti"
    pRegistra   = "Registrazione dell'applicazione"
    eArch       = "Componenti per l'architettura {0} non presenti nel pacchetto."
    eRuntime    = "Installazione del runtime .NET 10 non riuscita. Scaricarlo da https://dotnet.microsoft.com/download/dotnet/10.0 (Desktop Runtime per {0}) e ripetere l'installazione."
  }
  en = @{
    titolo      = "Bayran WinCleaner Setup"
    sottotitolo = "Version {0} · BayranLab Software"
    lingua      = "Language"
    cartella    = "Installation folder"
    sfoglia     = "Browse…"
    nota        = "Administrator privileges are not required."
    annulla     = "Cancel"
    installa    = "Install"
    inCorso     = "Installing"
    chiudi      = "Close"
    avvia       = "Launch"
    completata  = "Installation complete"
    esito       = "Bayran WinCleaner is available in the Start menu and on the Desktop."
    esito2      = "To remove it, use Windows «Installed apps». User data is preserved."
    fallita     = "Installation failed"
    scegliCart  = "Select the destination folder"
    pRuntime    = "Checking required components"
    pRuntimeNo  = "Installing the .NET 10 runtime"
    pCopia      = "Copying files"
    pColleg     = "Creating shortcuts"
    pRegistra   = "Registering the application"
    eArch       = "Components for the {0} architecture are missing from the package."
    eRuntime    = "The .NET 10 runtime could not be installed. Download it from https://dotnet.microsoft.com/download/dotnet/10.0 (Desktop Runtime for {0}) and run Setup again."
  }
}

# La lingua predefinita segue il sistema: italiano se il computer è italiano,
# inglese altrimenti. Il prodotto è distribuito fuori dall'Italia.
if (-not $lingua) {
  $lingua = if ((Get-Culture).TwoLetterISOLanguageName -eq "it") { "it" } else { "en" }
}
if (-not $T.ContainsKey($lingua)) { $lingua = "en" }

# ------------------------------------------------------- dove si installa ---

$predefinita = Join-Path $env:LOCALAPPDATA "Programs\Bayran WinCleaner"
$chiave = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BayranWinCleaner"

if (-not $cartella) {
  # Se l'applicazione è già installata, si aggiorna dove si trova. Senza
  # questo, un aggiornamento riporterebbe l'installazione nella cartella
  # predefinita lasciando la precedente sul disco.
  try {
    $g = (Get-ItemProperty $chiave -EA SilentlyContinue).InstallLocation
    if ($g -and (Test-Path $g)) { $cartella = $g }
  } catch { }
}
if (-not $cartella) { $cartella = $predefinita }

# ------------------------------------------------------------- il lavoro ---

$lavoro = {
  param($qui, $dove, $nome, $stato, $t, $lingua)

  function Passo($testo) { $stato.passo = $testo }

  try {
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") { "arm64" } else { "x64" }
    $sorgente = Join-Path $qui "programma\$arch"
    if (-not (Test-Path $sorgente)) {
      throw ($t.eArch -f $env:PROCESSOR_ARCHITECTURE)
    }

    # ---- 1. runtime ----
    # L'applicazione utilizza il runtime di sistema (27 MB invece di 130).
    Passo $t.pRuntime
    $ceIlRuntime = $false
    try {
      $elenco = & dotnet --list-runtimes 2>$null
      $ceIlRuntime = [bool]($elenco -match "Microsoft\.WindowsDesktop\.App 10\.")
    } catch { }
    if (-not $ceIlRuntime) {
      Passo $t.pRuntimeNo
      $ok = $false
      try {
        & winget install --id Microsoft.DotNet.DesktopRuntime.10 `
            --accept-source-agreements --accept-package-agreements -h 2>&1 | Out-Null
        $ok = $LASTEXITCODE -eq 0
      } catch { }
      if (-not $ok) { throw ($t.eRuntime -f $env:PROCESSOR_ARCHITECTURE) }
    }

    # ---- 2. copia ----
    Passo $t.pCopia
    if (Test-Path $dove) {
      Get-Process BayranWinCleaner -EA SilentlyContinue |
        Stop-Process -Force -EA SilentlyContinue
      Start-Sleep -Milliseconds 800
      # I dati dell'utente non risiedono qui: sono in AppData e vengono conservati.
      Remove-Item $dove -Recurse -Force -EA SilentlyContinue
    }
    New-Item -ItemType Directory -Force -Path $dove | Out-Null
    Copy-Item "$sorgente\*" $dove -Recurse -Force
    $exe = Join-Path $dove "BayranWinCleaner.exe"
    $stato.exe = $exe

    # La versione viene letta dall'eseguibile appena copiato, non scritta qui:
    # è la voce mostrata da Windows in "Installazione applicazioni" ed è la
    # stessa che l'applicazione legge per riconoscere sé stessa.
    $versione = (Get-Item $exe).VersionInfo.FileVersion
    if (-not $versione) { $versione = "0.0.0" }
    $versione = ($versione -split ' ')[0]
    # FileVersion espone quattro componenti (0.9.1.0), il prodotto ne dichiara
    # tre: lasciandole tutte, Windows mostrava 0.9.1.0 mentre l'applicazione
    # dichiarava 0.9.1.
    $pezzi = $versione -split '\.'
    if ($pezzi.Count -gt 3) { $versione = ($pezzi[0..2] -join '.') }
    $stato.versione = $versione

    # ---- 3. lingua scelta ----
    # L'applicazione la legge al primo avvio. File separato e non
    # impostazioni.json: unire JSON da PowerShell significherebbe rischiare di
    # sovrascrivere le preferenze di chi sta aggiornando.
    try {
      $dati = Join-Path $env:LOCALAPPDATA "BayranWinCleaner"
      New-Item -ItemType Directory -Force -Path $dati | Out-Null
      Set-Content -Path (Join-Path $dati "lingua.txt") -Value $lingua -Encoding ASCII
    } catch { }

    # ---- 4. collegamenti ----
    Passo $t.pColleg
    $ws = New-Object -ComObject WScript.Shell
    foreach ($d in @(
        (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"),
        [Environment]::GetFolderPath("Desktop"))) {
      $lnk = $ws.CreateShortcut((Join-Path $d "$nome.lnk"))
      $lnk.TargetPath = $exe
      $lnk.WorkingDirectory = $dove
      $lnk.IconLocation = $exe
      $lnk.Save()
    }

    # ---- 5. registrazione ----
    # Registra l'applicazione dove Windows elenca i programmi installati:
    # compare in "Installazione applicazioni" e si disinstalla da lì. È anche
    # la chiave che la sezione Applicazioni legge per riconoscere sé stessa.
    Passo $t.pRegistra
    $disinstalla = Join-Path $dove "Disinstalla.ps1"
    @"
`$ErrorActionPreference = 'SilentlyContinue'
Get-Process BayranWinCleaner | Stop-Process -Force
Start-Sleep -Milliseconds 800
Remove-Item '$dove' -Recurse -Force
Remove-Item (Join-Path `$env:APPDATA 'Microsoft\Windows\Start Menu\Programs\$nome.lnk') -Force
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) '$nome.lnk') -Force
Remove-Item 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BayranWinCleaner' -Recurse -Force
"@ | Set-Content -Encoding UTF8 $disinstalla

    $k = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BayranWinCleaner"
    New-Item -Path $k -Force | Out-Null
    Set-ItemProperty $k DisplayName     $nome
    Set-ItemProperty $k DisplayVersion  $versione
    Set-ItemProperty $k Publisher       "BayranLab Software"
    Set-ItemProperty $k DisplayIcon     $exe
    Set-ItemProperty $k InstallLocation $dove
    Set-ItemProperty $k NoModify 1 -Type DWord
    Set-ItemProperty $k NoRepair 1 -Type DWord
    Set-ItemProperty $k UninstallString `
      "powershell -NoProfile -ExecutionPolicy Bypass -File `"$disinstalla`""

    $stato.finito = $true
  }
  catch {
    $stato.errore = $_.Exception.Message
    $stato.finito = $true
  }
}

# ----------------------------------------------------------- senza schermo ---

if ($silenzioso) {
  $stato = [hashtable]::Synchronized(@{ passo = ""; finito = $false
                                        errore = ""; versione = ""; exe = "" })
  & $lavoro $qui $cartella $nome $stato $T[$lingua] $lingua
  if ($stato.errore) { Write-Error $stato.errore; exit 1 }
  Write-Output "installed: $($stato.versione) -> $cartella"
  exit 0
}

# ------------------------------------------------------------------ finestra ---

Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[void][Finestre]::SetProcessDPIAware()

$sfondo  = [Drawing.Color]::FromArgb(11, 24, 38)
$scheda  = [Drawing.Color]::FromArgb(22, 39, 58)
$testoC  = [Drawing.Color]::FromArgb(242, 247, 251)
$smorto  = [Drawing.Color]::FromArgb(150, 168, 184)
$accento = [Drawing.Color]::FromArgb(65, 171, 208)
$verde   = [Drawing.Color]::FromArgb(95, 209, 141)
$rosso   = [Drawing.Color]::FromArgb(232, 110, 110)

$gr = [Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
$sc = $gr.DpiX / 96.0
function P([int]$n) { [int]($n * $sc) }
$LARG = 660

$f = New-Object Windows.Forms.Form
$f.ClientSize = New-Object Drawing.Size((P $LARG), (P 486))
$f.StartPosition = "CenterScreen"
$f.FormBorderStyle = "FixedDialog"
$f.MaximizeBox = $false
$f.BackColor = $sfondo
$f.ForeColor = $testoC
$f.Font = New-Object Drawing.Font("Segoe UI", 10)
$icona = Join-Path $qui "bayran.ico"
if (Test-Path $icona) { $f.Icon = New-Object Drawing.Icon($icona) }

# Ogni elemento occupa l'intera larghezza utile e centra il proprio contenuto:
# è il modo per ottenere una colonna simmetrica senza calcolare a mano la
# posizione di ciascuna scritta.
function Centrata($y, $size, $col, $bold) {
  $l = New-Object Windows.Forms.Label
  $l.Location = New-Object Drawing.Point((P 40), (P $y))
  $l.Size = New-Object Drawing.Size((P ($LARG - 80)), (P 26))
  $l.TextAlign = "MiddleCenter"
  $st = if ($bold) { [Drawing.FontStyle]::Bold } else { [Drawing.FontStyle]::Regular }
  $l.Font = New-Object Drawing.Font("Segoe UI", $size, $st)
  $l.ForeColor = $col
  $l.BackColor = [Drawing.Color]::Transparent
  $f.Controls.Add($l)
  $l
}

$versioneAttesa = ""
try {
  $a = if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") { "arm64" } else { "x64" }
  $es = Join-Path $qui "programma\$a\BayranWinCleaner.exe"
  if (Test-Path $es) {
    $v = ((Get-Item $es).VersionInfo.FileVersion -split ' ')[0]
    $p = $v -split '\.'
    if ($p.Count -gt 3) { $v = ($p[0..2] -join '.') }
    $versioneAttesa = $v
  }
} catch { }

# --- intestazione ---
$logo = New-Object Windows.Forms.PictureBox
$logo.Size = New-Object Drawing.Size((P 88), (P 88))
$logo.Location = New-Object Drawing.Point((P (($LARG - 88) / 2)), (P 28))
$logo.SizeMode = "Zoom"
$pngLogo = Join-Path $qui "logo.png"
if (Test-Path $pngLogo) { $logo.Image = [Drawing.Image]::FromFile($pngLogo) }
$f.Controls.Add($logo)

$lNome = Centrata 128 16 $testoC $true
$lNome.Text = $nome
$lVers = Centrata 158 9.5 $smorto $false

$riga = New-Object Windows.Forms.Panel
$riga.Location = New-Object Drawing.Point((P 40), (P 194))
$riga.Size = New-Object Drawing.Size((P ($LARG - 80)), 1)
$riga.BackColor = [Drawing.Color]::FromArgb(45, 62, 82)
$f.Controls.Add($riga)

# --- lingua e cartella, in colonna centrata ---
$CAMPO = 476
$sinistra = [int](($LARG - $CAMPO) / 2)

$lLingua = Centrata 218 9.5 $smorto $false
$cbLingua = New-Object Windows.Forms.ComboBox
$cbLingua.DropDownStyle = "DropDownList"
$cbLingua.Location = New-Object Drawing.Point((P $sinistra), (P 244))
$cbLingua.Size = New-Object Drawing.Size((P $CAMPO), (P 28))
$cbLingua.BackColor = $scheda
$cbLingua.ForeColor = $testoC
$cbLingua.FlatStyle = "Flat"
[void]$cbLingua.Items.Add("Italiano")
[void]$cbLingua.Items.Add("English")
$cbLingua.SelectedIndex = $(if ($lingua -eq "it") { 0 } else { 1 })
# Il menu a tendina lo disegniamo noi. Impostare BackColor non basta: la voce
# selezionata e la tendina aperta vengono disegnate dal sistema con i propri
# colori, e su fondo scuro comparivano come una barra blu accesa.
$script:colScheda = $scheda
$script:colTesto  = $testoC
$script:colSel    = [Drawing.Color]::FromArgb(35, 62, 90)
$cbLingua.DrawMode = "OwnerDrawFixed"
$cbLingua.ItemHeight = (P 22)
$cbLingua.Add_DrawItem({
  param($mittente, $e)
  $selezionata = ($e.State -band [Windows.Forms.DrawItemState]::Selected) -ne 0
  $fondo = if ($selezionata) { $script:colSel } else { $script:colScheda }
  $e.Graphics.FillRectangle((New-Object Drawing.SolidBrush($fondo)), $e.Bounds)
  if ($e.Index -ge 0) {
    $sf = New-Object Drawing.StringFormat
    $sf.LineAlignment = [Drawing.StringAlignment]::Center
    $r = New-Object Drawing.RectangleF(
      ($e.Bounds.X + 8), $e.Bounds.Y, ($e.Bounds.Width - 8), $e.Bounds.Height)
    $e.Graphics.DrawString($mittente.Items[$e.Index], $mittente.Font,
      (New-Object Drawing.SolidBrush($script:colTesto)), $r, $sf)
  }
})
$f.Controls.Add($cbLingua)

$lCart = Centrata 288 9.5 $smorto $false
$txtCart = New-Object Windows.Forms.TextBox
$txtCart.Location = New-Object Drawing.Point((P $sinistra), (P 314))
$txtCart.Size = New-Object Drawing.Size((P ($CAMPO - 110)), (P 26))
$txtCart.BackColor = $scheda
$txtCart.ForeColor = $testoC
$txtCart.BorderStyle = "FixedSingle"
$txtCart.Text = $cartella
$f.Controls.Add($txtCart)

$bSfoglia = New-Object Windows.Forms.Button
$bSfoglia.Location = New-Object Drawing.Point((P ($sinistra + $CAMPO - 100)), (P 313))
$bSfoglia.Size = New-Object Drawing.Size((P 100), (P 28))
$bSfoglia.FlatStyle = "Flat"
$bSfoglia.BackColor = $sfondo
$bSfoglia.ForeColor = $smorto
$bSfoglia.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(60, 80, 102)
$bSfoglia.Font = New-Object Drawing.Font("Segoe UI", 9.5)
$f.Controls.Add($bSfoglia)

$lNota = Centrata 356 9 $smorto $false

# --- avanzamento ---
$barra = New-Object Windows.Forms.ProgressBar
$barra.Location = New-Object Drawing.Point((P $sinistra), (P 252))
$barra.Size = New-Object Drawing.Size((P $CAMPO), (P 6))
$barra.Style = "Marquee"
$barra.MarqueeAnimationSpeed = 26
$barra.Visible = $false
$f.Controls.Add($barra)

$lPasso = Centrata 274 9.5 $smorto $false
$lPasso.Visible = $false

# --- esito ---
$lEsito = New-Object Windows.Forms.Label
$lEsito.Location = New-Object Drawing.Point((P 60), (P 250))
$lEsito.Size = New-Object Drawing.Size((P ($LARG - 120)), (P 120))
$lEsito.TextAlign = "TopCenter"
$lEsito.Font = New-Object Drawing.Font("Segoe UI", 9.5)
$lEsito.ForeColor = $smorto
$lEsito.BackColor = [Drawing.Color]::Transparent
$lEsito.Visible = $false
$f.Controls.Add($lEsito)

# --- pulsanti, coppia centrata ---
$BOTT = 168
$GAP  = 16
$xSin = [int](($LARG - ($BOTT * 2 + $GAP)) / 2)
function Bottone($x, $primario) {
  $b = New-Object Windows.Forms.Button
  $b.Size = New-Object Drawing.Size((P $BOTT), (P 38))
  $b.Location = New-Object Drawing.Point((P $x), (P 418))
  $b.FlatStyle = "Flat"
  $st = if ($primario) { [Drawing.FontStyle]::Bold } else { [Drawing.FontStyle]::Regular }
  $b.Font = New-Object Drawing.Font("Segoe UI", 10, $st)
  if ($primario) {
    $b.BackColor = $accento
    $b.ForeColor = [Drawing.Color]::White
    $b.FlatAppearance.BorderSize = 0
  } else {
    $b.BackColor = $sfondo
    $b.ForeColor = $smorto
    $b.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(60, 80, 102)
  }
  $f.Controls.Add($b)
  $b
}
$bAnnulla = Bottone $xSin $false
$bAvanti  = Bottone ($xSin + $BOTT + $GAP) $true

# --- applica i testi nella lingua scelta ---
$script:L = $lingua
function Traduci {
  $t = $T[$script:L]
  $f.Text = $t.titolo
  $lVers.Text = ($t.sottotitolo -f $versioneAttesa)
  $lLingua.Text = $t.lingua
  $lCart.Text = $t.cartella
  $bSfoglia.Text = $t.sfoglia
  $lNota.Text = $t.nota
  $bAnnulla.Text = $t.annulla
  if ($bAvanti.Tag -ne "apri") { $bAvanti.Text = $t.installa }
}
Traduci

$cbLingua.Add_SelectedIndexChanged({
  $script:L = $(if ($cbLingua.SelectedIndex -eq 0) { "it" } else { "en" })
  Traduci
})

$bSfoglia.Add_Click({
  $d = New-Object Windows.Forms.FolderBrowserDialog
  $d.Description = $T[$script:L].scegliCart
  $d.SelectedPath = Split-Path -Parent $txtCart.Text
  if ($d.ShowDialog() -eq "OK") {
    $txtCart.Text = Join-Path $d.SelectedPath $nome
  }
})

$bAnnulla.Add_Click({ $f.Close() })

# --- esecuzione ---
$stato = [hashtable]::Synchronized(@{ passo = ""; finito = $false
                                      errore = ""; versione = ""; exe = "" })
$orologio = New-Object Windows.Forms.Timer
$orologio.Interval = 200

$bAvanti.Add_Click({
  if ($bAvanti.Tag -eq "apri") {
    if ($stato.exe -and (Test-Path $stato.exe)) { Start-Process $stato.exe }
    $f.Close()
    return
  }
  $t = $T[$script:L]
  $bAvanti.Enabled = $false
  $bAnnulla.Enabled = $false
  foreach ($c in @($cbLingua, $txtCart, $bSfoglia, $lLingua, $lCart, $lNota)) {
    $c.Visible = $false
  }
  $lNome.Text = $t.inCorso
  $barra.Visible = $true
  $lPasso.Visible = $true

  # L'installazione viene eseguita in un runspace separato: la finestra
  # continua a ridisegnare anche durante l'installazione del runtime .NET,
  # che può richiedere minuti.
  $script:spazio = [runspacefactory]::CreateRunspace()
  $script:spazio.Open()
  $script:ps = [powershell]::Create()
  $script:ps.Runspace = $script:spazio
  [void]$script:ps.AddScript($lavoro.ToString()).
        AddArgument($qui).AddArgument($txtCart.Text).AddArgument($nome).
        AddArgument($stato).AddArgument($T[$script:L]).AddArgument($script:L)
  [void]$script:ps.BeginInvoke()
  $orologio.Start()
})

$orologio.Add_Tick({
  $lPasso.Text = $stato.passo
  if (-not $stato.finito) { return }
  $orologio.Stop()
  $t = $T[$script:L]
  $barra.Visible = $false
  $lPasso.Visible = $false
  $lEsito.Visible = $true
  if ($stato.errore) {
    $lNome.Text = $t.fallita
    $lNome.ForeColor = $rosso
    $lEsito.Text = $stato.errore
    $bAnnulla.Text = $t.chiudi
    $bAnnulla.Enabled = $true
    $bAvanti.Visible = $false
    # con un solo pulsante la coppia non è più simmetrica: si centra quello
    $bAnnulla.Location = New-Object Drawing.Point((P ([int](($LARG - $BOTT) / 2))), (P 418))
  } else {
    $lNome.Text = $t.completata
    $lNome.ForeColor = $verde
    $lEsito.Text = $t.esito + [Environment]::NewLine + [Environment]::NewLine + $t.esito2
    $bAnnulla.Text = $t.chiudi
    $bAnnulla.Enabled = $true
    $bAvanti.Text = $t.avvia
    $bAvanti.Tag = "apri"
    $bAvanti.Enabled = $true
  }
  try { $script:ps.Dispose(); $script:spazio.Close() } catch { }
})

$f.Add_Shown({
  $f.Activate()
  # il fuoco sul pulsante e non sul menu: partendo sul menu, Windows lo
  # evidenziava e sembrava che fosse stato appena toccato
  $bAvanti.Focus()
  # 20 = DWMWA_USE_IMMERSIVE_DARK_MODE
  $uno = 1
  [void][Finestre]::DwmSetWindowAttribute($f.Handle, 20, [ref]$uno, 4)
})

[void]$f.ShowDialog()
