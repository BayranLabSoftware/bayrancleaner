Bayran WinCleaner - Setup
=========================

1. Run Installa.bat
2. Select the language and the destination folder, then click Install.
3. The application will be available in the Start menu and on the Desktop.

What Setup does
---------------
- copies the application to the selected folder
- installs the .NET 10 runtime, if not already present
- creates shortcuts in the Start menu and on the Desktop
- registers the application in Windows "Installed apps"

Administrator privileges are not required.

Windows SmartScreen notice
--------------------------
On first launch Windows may report an unrecognised application. The
application is not yet digitally signed. Select "More info", then
"Run anyway".

Uninstalling
------------
From Windows "Installed apps". User data and the operations log are kept in
%LOCALAPPDATA%\BayranWinCleaner even after uninstalling.

The package contains both architectures, x64 and ARM64: Setup selects the
correct one automatically.
