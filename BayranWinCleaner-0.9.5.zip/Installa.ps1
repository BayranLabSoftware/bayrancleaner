﻿# Da qui in avanti l'installazione la fa Installa.exe. Questo file resta solo
# come ponte per le versioni gia' distribuite: la 0.9.1, la 0.9.2 e la 0.9.3
# cercano `Installa.ps1` dentro il pacchetto scaricato e invocano quello,
# perche' al momento della loro compilazione l'installatore era uno script.
# Togliendolo, il loro aggiornamento automatico si fermerebbe con
# «il pacchetto scaricato non e' un pacchetto di Bayran».
#
# Deve restare UTF-8 CON BOM: Windows PowerShell 5.1 altrimenti lo legge come
# ANSI e muore sulla prima parola accentata.
param([switch]$silenzioso, [string]$lingua = "", [string]$cartella = "")

$qui = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe = Join-Path $qui "Installa.exe"
if (-not (Test-Path $exe)) {
  Write-Error "Installa.exe non e' accanto a questo script: pacchetto incompleto."
  exit 1
}

# Chi arriva qui e' sempre l'aggiornamento automatico, che non ha nessuno
# davanti allo schermo: si passa -silenzioso anche se non l'ha chiesto.
# `-dalponte`: il riavvio lo fa lo script che ci ha chiamati, dopo averci
# aspettati. Se lo facesse anche l'installatore si aprirebbero due finestre.
$argomenti = @("-silenzioso", "-dalponte")
if ($lingua)   { $argomenti += @("-lingua", $lingua) }
if ($cartella) { $argomenti += @("-cartella", $cartella) }

$p = Start-Process -FilePath $exe -ArgumentList $argomenti -Wait -PassThru
exit $p.ExitCode
