Bayran WinCleaner - Setup
=========================

1. Run Installa.exe
2. Select the language and the destination folder, then click Install.
3. The application will be available in the Start menu and on the Desktop.

What Setup does
---------------
- copies the application to the selected folder, with every component it
  needs (including the .NET runtime): nothing else has to be installed
- installs Microsoft Edge WebView2, only if it is not already present
  (Windows 11 includes it): it is downloaded from Microsoft and requires an
  Internet connection
- creates shortcuts in the Start menu and on the Desktop
- registers the application in Windows "Installed apps"

Administrator privileges are not required.

License
-------
(c) 2026 BayranLab Software. All rights reserved.
The application is free and protected by copyright: copying, modifying,
redistributing or decompiling it is not permitted. The full license is in
LICENSE.txt, also found in the installed application folder. Installing the
application constitutes acceptance of the license.

Windows SmartScreen notice
--------------------------
On first launch Windows may report an unrecognised application. The
application is not yet digitally signed. Select "More info", then
"Run anyway".

Uninstalling
------------
From Windows "Installed apps". User data and the operations log are kept in
%LOCALAPPDATA%\BayranWinCleaner even after uninstalling.

The package contains both architectures, x64 and ARM64: Setup selects the
correct one automatically.
